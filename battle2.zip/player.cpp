#include "player.h"

#include "ship.h"

Player::Player()
{
    
}


Player::~Player()
{
    for(auto it = _ships.begin();it!=_ships.end();++it)
    {
        delete *it;
    }
    _ships.clear();
}

bool Player::addShip(int col, int row)
{
    for (auto it = _ships.begin(); it != _ships.end(); ++it)
    {
        if ((*it)->_position.x() == row && (*it)->_position.y() == col)
        {
            return false;
        }
    }

    auto t = new Ship();
    t->_position = QPoint(row, col);
    _ships.push_back(t);
    return true;
}
