#include "gamemanager.h"

GameManager::GameManager()
{

}
