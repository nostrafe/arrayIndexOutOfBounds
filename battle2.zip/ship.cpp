#include "ship.h"

Ship::Ship()
{

}
