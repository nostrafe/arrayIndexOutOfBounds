#ifndef SHIP_H
#define SHIP_H

#include <QPoint>
#include <list>

using namespace std;

class Ship
{
public:
    Ship();

public:
    QPoint _position = QPoint(0,0);
    int _width;
    int _height;
    //list<QPoint> _destroiedParts;
};

#endif // SHIP_H
